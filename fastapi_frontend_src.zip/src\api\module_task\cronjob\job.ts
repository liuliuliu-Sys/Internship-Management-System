import { request } from "@utils";

const API_PATH = "/task/cronjob/job";

const JobAPI = {
  getSchedulerStatus() {
    return request<ApiResponse<SchedulerStatus>>({
      url: `${API_PATH}/scheduler/status`,
      method: "get",
    });
  },

  getSchedulerJobs() {
    return request<ApiResponse<SchedulerJob[]>>({
      url: `${API_PATH}/scheduler/jobs`,
      method: "get",
    });
  },

  startScheduler() {
    return request<ApiResponse>({
      url: `${API_PATH}/scheduler/start`,
      method: "post",
    });
  },

  pauseScheduler() {
    return request<ApiResponse>({
      url: `${API_PATH}/scheduler/pause`,
      method: "post",
    });
  },

  resumeScheduler() {
    return request<ApiResponse>({
      url: `${API_PATH}/scheduler/resume`,
      method: "post",
    });
  },

  shutdownScheduler() {
    return request<ApiResponse>({
      url: `${API_PATH}/scheduler/shutdown`,
      method: "post",
    });
  },

  clearAllJobs() {
    return request<ApiResponse>({
      url: `${API_PATH}/scheduler/jobs/clear`,
      method: "delete",
    });
  },

  getSchedulerConsole() {
    return request<ApiResponse<string>>({
      url: `${API_PATH}/scheduler/console`,
      method: "get",
    });
  },

  pauseJob(jobId: string) {
    return request<ApiResponse>({
      url: `${API_PATH}/task/pause/${jobId}`,
      method: "post",
    });
  },

  resumeJob(jobId: string) {
    return request<ApiResponse>({
      url: `${API_PATH}/task/resume/${jobId}`,
      method: "post",
    });
  },

  runJobNow(jobId: string) {
    return request<ApiResponse>({
      url: `${API_PATH}/task/run/${jobId}`,
      method: "post",
    });
  },

  removeJob(jobId: string) {
    return request<ApiResponse>({
      url: `${API_PATH}/task/remove/${jobId}`,
      method: "delete",
    });
  },

  modifyJob(jobId: string, body: Record<string, any>) {
    return request<ApiResponse>({
      url: `${API_PATH}/task/modify/${jobId}`,
      method: "put",
      data: body,
    });
  },

  getJobLogList(query: JobLogPageQuery) {
    return request<ApiResponse<PageResult<JobLogTable>>>({
      url: `${API_PATH}/log/list`,
      method: "get",
      params: query,
    });
  },

  getJobLogDetail(id: number) {
    return request<ApiResponse<JobLogTable>>({
      url: `${API_PATH}/log/detail/${id}`,
      method: "get",
    });
  },

  deleteJobLog(ids: number[]) {
    return request<ApiResponse>({
      url: `${API_PATH}/log/delete`,
      method: "delete",
      data: ids,
    });
  },
};

export default JobAPI;

export interface SchedulerStatus {
  status: string;
  is_running: boolean;
  job_count: number;
}

export interface SchedulerJob {
  id: string;
  name: string;
  trigger: string;
  next_run_time?: string;
  status: number;
}

export interface JobLogPageQuery extends PageQuery, UserByQueryParams {
  job_id?: string;
  job_name?: string;
  trigger_type?: string;
  status?: number;
}

export interface JobLogTable extends BaseType {
  job_id: string;
  job_name?: string;
  trigger_type?: string;
  next_run_time?: string;
  job_state?: string;
  result?: string;
  error?: string;
  status?: number;
  description?: string;
}
