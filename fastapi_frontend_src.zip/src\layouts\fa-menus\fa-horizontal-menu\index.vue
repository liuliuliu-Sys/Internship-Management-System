<!-- 水平菜单 -->
<template>
  <div id="app-menu-top" class="flex-1 overflow-hidden">
    <ElMenu
      :ellipsis="true"
      mode="horizontal"
      :default-active="routerPath"
      :text-color="isDark ? 'var(--fa-gray-800)' : 'var(--fa-gray-700)'"
      :popper-offset="-6"
      background-color="transparent"
      :show-timeout="50"
      :hide-timeout="50"
      popper-class="horizontal-menu-popper"
      class="w-full border-none"
    >
      <FaHorizontalSubmenu
        v-for="item in filteredMenuItems"
        :key="item.path"
        :item="item"
        :level="0"
      />
    </ElMenu>
  </div>
</template>

<script setup lang="ts">
import { useSettingsStore } from "@stores";
import type { AppRouteRecord } from "@/types/router";

defineOptions({ name: "FaHorizontalMenu" });

const settingStore = useSettingsStore();
const { isDark } = storeToRefs(settingStore);

interface Props {
  /** 菜单列表数据 */
  list: AppRouteRecord[];
}

const route = useRoute();

const props = withDefaults(defineProps<Props>(), {
  list: () => [],
});

/**
 * 过滤后的菜单项列表
 * 只显示未隐藏的菜单项
 */
const filteredMenuItems = computed(() => {
  return filterMenuItems(props.list);
});

/**
 * 当前激活的路由路径
 * 用于菜单高亮显示
 */
const routerPath = computed(() => String(route.meta.activePath || route.path));

/**
 * 递归过滤菜单项，移除隐藏的菜单
 * 如果一个父菜单的所有子菜单都被隐藏，则父菜单也会被隐藏
 * @param items 菜单项数组
 * @returns 过滤后的菜单项数组
 */
const filterMenuItems = (items: AppRouteRecord[]): AppRouteRecord[] => {
  return items
    .filter((item) => {
      // 如果当前项被隐藏，直接过滤掉
      if (item.meta.isHide) {
        return false;
      }

      // 如果有子菜单，递归过滤子菜单
      if (item.children && item.children.length > 0) {
        const filteredChildren = filterMenuItems(item.children);
        // 如果所有子菜单都被过滤掉了，则隐藏父菜单
        return filteredChildren.length > 0;
      }

      // 叶子节点且未被隐藏，保留
      return true;
    })
    .map((item) => ({
      ...item,
      children: item.children ? filterMenuItems(item.children) : undefined,
    }));
};
</script>

<style scoped>
/* Remove el-menu bottom border */
:deep(.el-menu) {
  border-bottom: none !important;
}

/* Remove default styles for first-level menu items */
:deep(.el-menu-item[tabindex="0"]) {
  background-color: transparent !important;
  border: none !important;
}

/* Remove bottom border from submenu titles */
:deep(.el-menu--horizontal .el-sub-menu__title) {
  padding: 0 30px 0 10px !important;
  border: 0 !important;
}

/* Horizontal menu item hover background */
:deep(.el-menu-item:hover),
:deep(.el-sub-menu__title:hover) {
  background-color: var(--el-color-primary-light-9) !important;
}

/* 暗色模式：水平菜单内联项（非弹出层）hover */
.dark {
  :deep(.el-menu-item:hover),
  :deep(.el-sub-menu__title:hover) {
    background-color: color-mix(in srgb, var(--el-color-primary) 15%, transparent) !important;
  }
}
</style>

<style lang="scss">
/* 水平菜单弹出层 hover 背景（popper 在组件树外，需 un-scoped） */
.horizontal-menu-popper {
  .el-menu-item:hover,
  .el-sub-menu__title:hover {
    background-color: var(--el-color-primary-light-9) !important;
    border-radius: 6px;
  }
}

/* 暗色模式：hover 背景使用半透明主题色 */
.dark {
  .horizontal-menu-popper {
    .el-menu-item:hover,
    .el-sub-menu__title:hover {
      background-color: color-mix(in srgb, var(--el-color-primary) 15%, transparent) !important;
    }
  }
}
</style>
