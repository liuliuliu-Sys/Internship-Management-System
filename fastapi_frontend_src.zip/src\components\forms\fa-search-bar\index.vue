<!-- 表格搜索组件 -->
<!-- 支持常用表单组件、自定义组件、插槽、校验、隐藏表单项 -->
<!-- 写法同 ElementPlus 官方文档组件，把属性写在 props 里面就可以了 -->
<template>
  <section class="fa-search-bar fa-card-xs" :class="{ 'is-expanded': isExpanded }">
    <ElForm
      ref="formRef"
      :model="modelValue"
      :label-position="labelPosition"
      @keyup.enter="emit('search', modelValue)"
      v-bind="{ ...$attrs }"
    >
      <ElRow :gutter="gutter">
        <ElCol
          v-for="item in visibleFormItems"
          :key="item.key"
          :xs="getColSpan(item.span, 'xs')"
          :sm="getColSpan(item.span, 'sm')"
          :md="getColSpan(item.span, 'md')"
          :lg="getColSpan(item.span, 'lg')"
          :xl="getColSpan(item.span, 'xl')"
        >
          <ElFormItem
            :prop="item.key"
            :label-width="item.label ? item.labelWidth || labelWidth : undefined"
          >
            <template #label v-if="item.label">
              <component v-if="typeof item.label !== 'string'" :is="item.label" />
              <span v-else>{{ item.label }}</span>
            </template>
            <!-- 创建人插槽 -->
            <template v-if="item.key === 'created_id' && !$slots.created_id">
              <div class="w-full min-w-0">
                <FaUserTableSelect
                  :model-value="modelValue?.created_id == null ? undefined : modelValue.created_id"
                  @update:model-value="
                    (v: number | undefined) => {
                      modelValue['created_id'] = v;
                    }
                  "
                  @confirm-click="emitImmediateSearch"
                  @clear-click="emitImmediateSearch"
                />
              </div>
            </template>
            <!-- 更新人插槽 -->
            <template v-else-if="item.key === 'updated_id' && !$slots.updated_id">
              <div class="w-full min-w-0">
                <FaUserTableSelect
                  :model-value="modelValue?.updated_id == null ? undefined : modelValue.updated_id"
                  @update:model-value="
                    (v: number | undefined) => {
                      modelValue['updated_id'] = v;
                    }
                  "
                  @confirm-click="emitImmediateSearch"
                  @clear-click="emitImmediateSearch"
                />
              </div>
            </template>
            <template v-else>
              <slot :name="item.key" :item="item" :modelValue="modelValue">
                <component
                  :is="getComponent(item)"
                  :model-value="getFieldValue(item.key)"
                  @update:model-value="setFieldValue(item.key, $event)"
                  v-bind="getProps(item)"
                >
                  <!-- 下拉选择 -->
                  <template v-if="item.type === 'select' && getProps(item)?.options">
                    <ElOption
                      v-for="option in getProps(item).options"
                      v-bind="option"
                      :key="option.value"
                    />
                  </template>

                  <!-- 复选框组 -->
                  <template v-if="item.type === 'checkboxgroup' && getProps(item)?.options">
                    <ElCheckbox
                      v-for="option in getProps(item).options"
                      v-bind="option"
                      :key="option.value"
                    />
                  </template>

                  <!-- 单选框组 -->
                  <template v-if="item.type === 'radiogroup' && getProps(item)?.options">
                    <ElRadio
                      v-for="option in getProps(item).options"
                      v-bind="option"
                      :key="option.value"
                    />
                  </template>

                  <!-- 动态插槽支持 -->
                  <template
                    v-for="(slotFn, slotName) in getSlots(item)"
                    :key="slotName"
                    #[slotName]
                  >
                    <component :is="slotFn" />
                  </template>
                </component>
              </slot>
            </template>
          </ElFormItem>
        </ElCol>
        <ElCol :xs="24" :sm="24" :md="span" :lg="span" :xl="span" class="action-column">
          <div class="action-buttons-wrapper" :style="actionButtonsStyle">
            <div class="form-buttons">
              <ElTooltip
                v-if="showReset"
                :content="t('table.searchBar.resetTooltip')"
                placement="top"
              >
                <ElButton class="reset-button" @click="handleReset" v-ripple>
                  <template #icon>
                    <Refresh />
                  </template>
                  {{ t("table.searchBar.reset") }}
                </ElButton>
              </ElTooltip>
              <ElTooltip
                v-if="showSearch"
                :content="t('table.searchBar.searchTooltip')"
                placement="top"
              >
                <ElButton
                  type="primary"
                  class="search-button"
                  @click="handleSearch"
                  v-ripple
                  :disabled="disabledSearch"
                >
                  <template #icon>
                    <Search />
                  </template>
                  {{ t("table.searchBar.search") }}
                </ElButton>
              </ElTooltip>
            </div>
            <div v-if="shouldShowExpandToggle" class="filter-toggle" @click="toggleExpand">
              <span>{{ expandToggleText }}</span>
              <div class="icon-wrapper">
                <ElIcon>
                  <ArrowUpBold v-if="isExpanded" />
                  <ArrowDownBold v-else />
                </ElIcon>
              </div>
            </div>
          </div>
        </ElCol>
      </ElRow>
    </ElForm>
  </section>
</template>

<script setup lang="ts">
import { ArrowUpBold, ArrowDownBold, Refresh, Search } from "@element-plus/icons-vue";
import { useWindowSize, onKeyStroke } from "@vueuse/core";
import { useI18n } from "vue-i18n";
import { type Component } from "vue";
import FaDatePicker from "@/components/forms/fa-search-bar/FaDatePicker.vue";
import FaUserTableSelect from "./FaUserTableSelect.vue";
import {
  getAuditSearchFormItems,
  type GetAuditSearchFormItemsOptions,
} from "./auditSearchFormItems";
import {
  ElCascader,
  ElCheckbox,
  ElCheckboxGroup,
  ElInput,
  ElInputTag,
  ElInputNumber,
  ElRadioGroup,
  ElRate,
  ElSelect,
  ElSlider,
  ElSwitch,
  ElTimePicker,
  ElTimeSelect,
  ElTreeSelect,
  type FormInstance,
} from "element-plus";
import {
  cloneModelValue as cloneModelValueShared,
  sanitizeOutputValue as sanitizeOutputValueShared,
  getProps as getPropsShared,
  getSlots as getSlotsShared,
  getColSpan as getColSpanShared,
  useSanitizeOutputOptions,
  type SanitizeOutputOptions,
} from "../composables/useFormBase";

defineOptions({ name: "FaSearchBar" });

// Ctrl+Enter 快捷键触发搜索
onKeyStroke("Enter", (e: KeyboardEvent) => {
  if (e.ctrlKey || e.metaKey) {
    e.preventDefault();
    handleSearch();
  }
});

const componentMap = {
  input: ElInput, // 输入框
  inputTag: ElInputTag, // 标签输入框
  number: ElInputNumber, // 数字输入框
  select: ElSelect, // 选择器
  switch: ElSwitch, // 开关
  checkbox: ElCheckbox, // 复选框
  checkboxgroup: ElCheckboxGroup, // 复选框组
  radiogroup: ElRadioGroup, // 单选框组
  date: FaDatePicker, // 日期选择器
  daterange: FaDatePicker, // 日期范围选择器
  datetime: FaDatePicker, // 日期时间选择器
  datetimerange: FaDatePicker, // 日期时间范围选择器
  rate: ElRate, // 评分
  slider: ElSlider, // 滑块
  cascader: ElCascader, // 级联选择器
  timepicker: ElTimePicker, // 时间选择器
  timeselect: ElTimeSelect, // 时间选择
  treeselect: ElTreeSelect, // 树选择器
};

const { width } = useWindowSize();
const { t } = useI18n();
const isMobile = computed(() => width.value < 500); // 表单窄布局阈值
/** H5 压缩模式：收起时只显示 1 个搜索项 */
const h5Compact = computed(() => width.value < 768);
const maxItemsPerRow = computed(() => (h5Compact.value ? 1 : Math.floor(24 / props.span) - 1));

const formInstance = useTemplateRef<FormInstance>("formRef");

// 表单项配置
export interface SearchFormItem {
  /** 表单项的唯一标识 */
  key: string;
  /** 表单项的标签文本或自定义渲染函数 */
  label: string | (() => VNode) | Component;
  /** 表单项标签的宽度，会覆盖 Form 的 labelWidth */
  labelWidth?: string | number;
  /** 表单项类型，支持预定义的组件类型 */
  type?: keyof typeof componentMap | string;
  /** 自定义渲染函数或组件，用于渲染自定义组件（优先级高于 type） */
  render?: (() => VNode) | Component;
  /** 是否隐藏该表单项 */
  hidden?: boolean;
  /** 是否仅在展开状态下显示（用于审计字段等次要字段） */
  expandOnly?: boolean;
  /** 表单项占据的列宽，基于24格栅格系统 */
  span?: number;
  /** 选项数据，用于 select、checkbox-group、radio-group 等 */
  options?: Record<string, any>;
  /** 传递给表单项组件的属性 */
  props?: Record<string, any>;
  /** 表单项的插槽配置 */
  slots?: Record<string, (() => any) | undefined>;
  /** 表单项的占位符文本 */
  placeholder?: string;
  /** 更多属性配置请参考 ElementPlus 官方文档 */
}

// 表单配置
interface Props {
  /** 表单数据 */
  items: SearchFormItem[];
  /** 每列的宽度（基于 24 格布局） */
  span?: number;
  /** 表单控件间隙 */
  gutter?: number;
  /** 展开/收起 */
  isExpand?: boolean;
  /** 默认是否展开（仅在 showExpand 为 true 且 isExpand 为 false 时生效） */
  defaultExpanded?: boolean;
  /** 表单域标签的位置 */
  labelPosition?: "left" | "right" | "top";
  /** 文字宽度 */
  labelWidth?: string | number;
  /** 是否需要展示，收起 */
  showExpand?: boolean;
  /** 按钮靠左对齐限制（表单项小于等于该值时） */
  buttonLeftLimit?: number;
  /** 是否显示重置按钮 */
  showReset?: boolean;
  /** 是否显示搜索按钮 */
  showSearch?: boolean;
  /** 是否禁用搜索按钮 */
  disabledSearch?: boolean;
  /** 搜索时是否清洗空值 */
  sanitizeOutput?: Partial<SanitizeOutputOptions>;
  /** 是否自动追加审计四字段（创建人/更新人/创建时间/更新时间） */
  includeAudit?: boolean;
  /** 传给 getAuditSearchFormItems 的选项 */
  auditItemOptions?: GetAuditSearchFormItemsOptions;
  /** 表单校验规则（通过 $attrs 透传至 ElForm） */
}

const props = withDefaults(defineProps<Props>(), {
  items: () => [],
  span: 6,
  gutter: 12,
  isExpand: false,
  labelPosition: "right",
  labelWidth: "70px",
  showExpand: true,
  defaultExpanded: false,
  buttonLeftLimit: 0,
  showReset: true,
  showSearch: true,
  disabledSearch: false,
  sanitizeOutput: () => ({}),
  includeAudit: false,
});

interface Emits {
  reset: [];
  search: [Record<string, any>];
}

const emit = defineEmits<Emits>();

const modelValue = defineModel<Record<string, any>>({ default: {} });
const initialModelValue = ref<Record<string, any>>({});

// 审计字段配置
const auditItems = computed(() => getAuditSearchFormItems(props.auditItemOptions));

// 合并业务字段和审计字段
const mergedItems = computed(() => {
  if (!props.includeAudit) return props.items;
  return [...props.items, ...auditItems.value];
});

// 保存组件初始化时的表单快照，用于 reset 时恢复默认筛选条件。
initialModelValue.value = cloneModelValueShared(modelValue.value);

const sanitizeOutputOptions = useSanitizeOutputOptions(props.sanitizeOutput);

// 模板引用的函数（从公共 composable 重新导出，使模板可访问）
const getColSpan = (itemSpan: number | undefined, breakpoint: any) =>
  getColSpanShared(itemSpan, span.value, breakpoint);
const getProps = getPropsShared;
const getSlots = getSlotsShared;

/**
 * 是否展开状态
 */
const isExpanded = ref(props.defaultExpanded);

// 当外部控制 isExpand 为 true 时，同步内部展开状态
watch(
  () => props.isExpand,
  (val) => {
    if (val === true) {
      isExpanded.value = true;
    }
  }
);

// 搜索表单清空输入时不保留空字符串，避免后续请求携带空字段。
const normalizeFieldValue = (value: unknown) => {
  return value === "" ? undefined : value;
};

const getFieldValue = (key: string) => modelValue.value[key];

const setFieldValue = (key: string, value: unknown) => {
  const normalizedValue = normalizeFieldValue(value);

  if (normalizedValue === undefined) {
    delete modelValue.value[key];
    return;
  }

  modelValue.value[key] = normalizedValue;
};

const getSanitizedOutput = () => {
  return (sanitizeOutputValueShared(
    cloneModelValueShared(modelValue.value),
    sanitizeOutputOptions.value
  ) || {}) as Record<string, any>;
};

// 组件
const getComponent = (item: SearchFormItem) => {
  // 优先使用 render 函数或组件渲染自定义组件
  if (item.render) {
    return item.render;
  }
  // 使用 type 获取预定义组件
  const { type } = item;
  return componentMap[type as keyof typeof componentMap] || componentMap["input"];
};

const emitImmediateSearch = async () => {
  const valid = (await formInstance.value?.validate?.().catch(() => false)) ?? true;
  if (!valid) return;
  emit("search", getSanitizedOutput());
};

/**
 * 可见的表单项
 */
const visibleFormItems = computed(() => {
  const filteredItems = mergedItems.value.filter((item) => !item.hidden);
  const shouldShowLess = !props.isExpand && !isExpanded.value;
  if (shouldShowLess) {
    // 收起时：只显示非 expandOnly 的字段，且不超过最大数量
    const nonExpandOnlyItems = filteredItems.filter((item) => !item.expandOnly);
    return nonExpandOnlyItems.slice(0, maxItemsPerRow.value);
  }
  // 展开时：显示所有字段
  return filteredItems;
});

/**
 * 非隐藏表单项总数（包含审计字段）
 */
const visibleItemCount = computed(() => mergedItems.value.filter((item) => !item.hidden).length);

/**
 * 是否应该显示展开/收起按钮
 * 当合并后的总字段数超过一行可展示数量时显示展开按钮
 */
const shouldShowExpandToggle = computed(() => {
  return !props.isExpand && props.showExpand && visibleItemCount.value > maxItemsPerRow.value;
});

/**
 * 展开/收起按钮文本
 */
const expandToggleText = computed(() => {
  return isExpanded.value ? t("table.searchBar.collapse") : t("table.searchBar.expand");
});

/**
 * 操作按钮样式
 */
const actionButtonsStyle = computed(() => ({
  "justify-content": isMobile.value
    ? "flex-end"
    : props.items.filter((item) => !item.hidden).length <= props.buttonLeftLimit
      ? "flex-start"
      : "flex-end",
}));

/**
 * 切换展开/收起状态
 */
const toggleExpand = () => {
  isExpanded.value = !isExpanded.value;
};

/**
 * 处理重置事件
 */
const handleReset = () => {
  // 重置表单字段（UI 层）
  formInstance.value?.resetFields();

  // 恢复初始表单值，保留默认搜索条件而不是简单清空。
  Object.keys(modelValue.value).forEach((key) => {
    delete modelValue.value[key];
  });
  Object.assign(modelValue.value, cloneModelValueShared(initialModelValue.value));

  // 触发 reset 事件
  emit("reset");
};

/**
 * 处理搜索事件
 */
const handleSearch = async () => {
  const valid = (await formInstance.value?.validate?.().catch(() => false)) ?? true;
  if (!valid) return;
  // 对外只抛出清洗后的查询参数，避免接口收到空数组/空字符串。
  emit("search", getSanitizedOutput());
};

defineExpose({
  ref: formInstance,
  validate: (...args: any[]) => formInstance.value?.validate(...args),
  reset: handleReset,
  // 允许外部在手动组装请求前直接读取清洗后的参数。
  getOutput: getSanitizedOutput,
});

// 解构 props 以便在模板中直接使用
const { span, gutter, labelPosition, labelWidth } = toRefs(props);
</script>

<style lang="scss" scoped>
.fa-search-bar {
  padding: 15px 20px 0;

  .action-column {
    flex: 1;
    max-width: 100%;

    .action-buttons-wrapper {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: flex-end;
      margin-bottom: 12px;
    }

    .form-buttons {
      display: flex;
      gap: 8px;
    }

    .filter-toggle {
      display: flex;
      align-items: center;
      margin-left: 10px;
      line-height: 32px;
      color: var(--theme-color);
      cursor: pointer;
      transition: color 0.2s ease;

      &:hover {
        color: var(--ElColor-primary);
      }

      span {
        font-size: 14px;
        user-select: none;
      }

      .icon-wrapper {
        display: flex;
        align-items: center;
        margin-left: 4px;
        font-size: 14px;
        transition: transform 0.2s ease;
      }
    }
  }
}

// 响应式优化
@media (width <= 768px) {
  .fa-search-bar {
    padding: 16px 16px 0;

    .action-column {
      .action-buttons-wrapper {
        flex-direction: row;
        gap: 8px;
        align-items: center;
        justify-content: center;

        .form-buttons {
          justify-content: center;
        }

        .filter-toggle {
          justify-content: center;
          margin-left: 0;
        }
      }
    }
  }
}
</style>
