<template>
  <template v-for="(item, index) in filteredMenuItems" :key="getUniqueKey(item, index)">
    <ElSubMenu v-if="hasChildren(item)" :index="item.path || item.meta.title" :level="level">
      <template #title>
        <div class="menu-icon flex items-center justify-center">
          <FaMenuRouteIcon
            :icon="item.meta.icon"
            :color="theme?.iconColor"
            :style="{ color: theme.iconColor }"
          />
        </div>
        <span class="menu-name">
          {{ formatMenuTitle(item.meta.title) }}
        </span>
        <div
          v-if="item.meta.showBadge && !item.meta.showTextBadge"
          class="fa-badge"
          :style="'right: 10px'"
        />
      </template>

      <FaSidebarSubmenu
        :list="item.children"
        :level="level + 1"
        :theme="theme"
        @close="closeMenu"
      />
    </ElSubMenu>

    <ElMenuItem
      v-else
      :index="isExternalLink(item) ? '' : item.path || item.meta.title"
      :level-item="level + 1"
      @click="goPage(item)"
    >
      <div class="menu-icon flex items-center justify-center">
        <FaMenuRouteIcon
          :icon="item.meta.icon"
          :color="theme?.iconColor"
          :style="{ color: theme.iconColor }"
        />
      </div>
      <div
        v-show="item.meta.showBadge && !item.meta.showTextBadge && level === 0 && !menuOpen"
        class="fa-badge"
        :style="'right: 5px'"
      />

      <template #title>
        <span class="menu-name">
          {{ formatMenuTitle(item.meta.title) }}
        </span>
        <div v-if="item.meta.showBadge && !item.meta.showTextBadge" class="fa-badge" />
        <div
          v-if="item.meta.showBadge && item.meta.showTextBadge && (level > 0 || menuOpen)"
          class="fa-text-badge"
        >
          {{ item.meta.showTextBadge }}
        </div>
      </template>
    </ElMenuItem>
  </template>
</template>

<script setup lang="ts">
import { computed } from "vue";
import { formatMenuTitle, handleMenuJump } from "@utils";
import { useSettingsStore } from "@stores";
import type { AppRouteRecord } from "@/types/router";

defineOptions({ name: "FaSidebarSubmenu" });

interface MenuTheme {
  iconColor?: string;
}

interface Props {
  /** 菜单标题 */
  title?: string;
  /** 菜单列表 */
  list?: AppRouteRecord[];
  /** 主题配置 */
  theme?: MenuTheme;
  /** 菜单层级 */
  level?: number;
}

interface Emits {
  /** 关闭菜单事件 */
  (e: "close"): void;
}

const props = withDefaults(defineProps<Props>(), {
  title: "",
  list: () => [],
  theme: () => ({}),
  level: 0,
});

const emit = defineEmits<Emits>();

const settingStore = useSettingsStore();

const { menuOpen } = storeToRefs(settingStore);

/**
 * 过滤后的菜单项列表
 * 只显示未隐藏的菜单项
 */
const filteredMenuItems = computed(() => filterRoutes(props.list));

/**
 * 跳转到指定页面
 * @param item 菜单项数据
 */
const goPage = (item: AppRouteRecord): void => {
  closeMenu();
  handleMenuJump(item);
};

/**
 * 关闭菜单
 * 触发父组件的关闭事件
 */
const closeMenu = (): void => {
  emit("close");
};

/**
 * 判断菜单项本身是否可以作为可点击页面保留在菜单中
 */
const isNavigableRoute = (item: AppRouteRecord): boolean => {
  if (item.meta?.isHide) {
    return false;
  }
  if (item.meta?.shellRoute && item.path?.trim()) {
    return true;
  }
  return !!(
    ((item.path && item.path.trim()) || item.meta.link || item.meta.isIframe === true) &&
    (item.component || item.meta.link || item.meta.isIframe === true)
  );
};

/**
 * 递归过滤菜单路由，移除隐藏的菜单项
 * 但如果父菜单本身就是可访问页面，则即使子菜单都被隐藏也应该保留
 * @param items 菜单项数组
 * @returns 过滤后的菜单项数组
 */
const filterRoutes = (items: AppRouteRecord[]): AppRouteRecord[] => {
  return items
    .filter((item) => {
      // 如果当前项被隐藏，直接过滤掉
      if (item.meta.isHide) {
        return false;
      }

      // 如果有子菜单，递归过滤子菜单
      if (item.children && item.children.length > 0) {
        const filteredChildren = filterRoutes(item.children);
        // 目录菜单要求有可见子菜单；页面菜单则允许仅保留自身
        return filteredChildren.length > 0 || isNavigableRoute(item);
      }

      // 叶子节点且未被隐藏，保留
      return isNavigableRoute(item);
    })
    .map((item) => ({
      ...item,
      children: item.children ? filterRoutes(item.children) : undefined,
    }));
};

/**
 * 判断菜单项是否包含可见的子菜单
 * @param item 菜单项数据
 * @returns 是否包含可见的子菜单
 */
const hasChildren = (item: AppRouteRecord): boolean => {
  if (!item.children || item.children.length === 0) {
    return false;
  }
  // 递归检查是否有可见的子菜单
  const filteredChildren = filterRoutes(item.children);
  return filteredChildren.length > 0;
};

/**
 * 判断是否为外部链接
 * @param item 菜单项数据
 * @returns 是否为外部链接
 */
const isExternalLink = (item: AppRouteRecord): boolean => {
  return !!(item.meta.link && !item.meta.isIframe);
};

/**
 * 生成唯一的 key
 * 使用 path、title 和 index 组合确保唯一性
 * @param item 菜单项数据
 * @param index 索引
 * @returns 唯一的 key
 */
const getUniqueKey = (item: AppRouteRecord, index: number): string => {
  return `${item.path || item.meta.title || "menu"}-${props.level}-${index}`;
};
</script>
