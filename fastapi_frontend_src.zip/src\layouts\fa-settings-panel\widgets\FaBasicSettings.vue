<template>
  <div>
    <FaSectionTitle :title="$t('setting.basics.title')" class="mt-10" />
    <FaSettingItem
      v-for="config in basicSettingsConfig"
      :key="config.key"
      :config="config"
      :model-value="getSettingValue(config.key)"
      @change="handleSettingChange(config.handler, $event)"
    />
  </div>
</template>

<script setup lang="ts">
import { useSettingsStore } from "@stores";

defineOptions({ name: "FaBasicSettings" });
import { useSettingsConfig } from "../composables/useSettingsConfig";
import { useSettingsHandlers } from "../composables/useSettingsHandlers";
import { storeToRefs } from "pinia";

const settingStore = useSettingsStore();
const { basicSettingsConfig } = useSettingsConfig();
const { basicHandlers } = useSettingsHandlers();

// 获取store的响应式状态
const {
  uniqueOpened,
  showMenuButton,
  showFastEnter,
  showRefreshButton,
  showCrumbs,
  showWorkTab,
  showLanguage,
  showMenuSearch,
  showFullscreen,
  showSizeSelect,
  showNotification,
  showNprogress,
  colorWeak,
  watermarkVisible,
  showAppLogo,
  showGuide,
  grayMode,
  userEnableAi,
  menuOpenWidth,
  tabStyle,
  pageTransition,
  customRadius,
} = storeToRefs(settingStore);

// 创建设置值映射
const settingValueMap = {
  uniqueOpened,
  showMenuButton,
  showFastEnter,
  showRefreshButton,
  showCrumbs,
  showWorkTab,
  showLanguage,
  showMenuSearch,
  showFullscreen,
  showSizeSelect,
  showNotification,
  showNprogress,
  colorWeak,
  watermarkVisible,
  showAppLogo,
  showGuide,
  grayMode,
  userEnableAi,
  menuOpenWidth,
  tabStyle,
  pageTransition,
  customRadius,
};

// 获取设置值的方法
const getSettingValue = (key: string) => {
  const settingRef = settingValueMap[key as keyof typeof settingValueMap];
  return settingRef?.value ?? null;
};

// 统一的设置变更处理
const handleSettingChange = (handlerName: string, value: any) => {
  const handler = (basicHandlers as Record<string, (...args: any[]) => any>)[handlerName];
  if (typeof handler === "function") {
    handler(value);
  } else {
    console.warn(`Handler "${handlerName}" not found in basicHandlers`);
  }
};
</script>
