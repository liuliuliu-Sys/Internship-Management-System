/**
 * Auth 认证令牌管理。
 *
 * 注意：令牌存储直接操作 localStorage / sessionStorage，而非经过 @utils/storage 的
 * Storage 工具类。这是因为：
 * 1. 令牌使用固定键名（access_token / refresh_token），不需要版本化键名前缀
 * 2. rememberMe 机制需要在两端（localStorage / sessionStorage）间切换
 * 3. 令牌值已是字符串，无需 JSON 序列化/反序列化
 *
 * @module Auth
 */

const AUTH_KEYS = {
  ACCESS_TOKEN: "access_token",
  REFRESH_TOKEN: "refresh_token",
  REMEMBER_ME: "remember_me",
} as const;

export class Auth {
  static isLoggedIn(): boolean {
    return !!Auth.getAccessToken();
  }

  static getAccessToken(): string {
    const isRememberMe = Auth.getRememberMe();
    return isRememberMe
      ? localStorage.getItem(AUTH_KEYS.ACCESS_TOKEN) || ""
      : sessionStorage.getItem(AUTH_KEYS.ACCESS_TOKEN) || "";
  }

  static getRefreshToken(): string {
    const isRememberMe = Auth.getRememberMe();
    return isRememberMe
      ? localStorage.getItem(AUTH_KEYS.REFRESH_TOKEN) || ""
      : sessionStorage.getItem(AUTH_KEYS.REFRESH_TOKEN) || "";
  }

  static setTokens(accessToken: string, refreshToken: string, rememberMe: boolean): void {
    localStorage.setItem(AUTH_KEYS.REMEMBER_ME, String(rememberMe));

    if (rememberMe) {
      localStorage.setItem(AUTH_KEYS.ACCESS_TOKEN, accessToken);
      localStorage.setItem(AUTH_KEYS.REFRESH_TOKEN, refreshToken);
    } else {
      sessionStorage.setItem(AUTH_KEYS.ACCESS_TOKEN, accessToken);
      sessionStorage.setItem(AUTH_KEYS.REFRESH_TOKEN, refreshToken);
      localStorage.removeItem(AUTH_KEYS.ACCESS_TOKEN);
      localStorage.removeItem(AUTH_KEYS.REFRESH_TOKEN);
    }
  }

  static clearAuth(): void {
    localStorage.removeItem(AUTH_KEYS.ACCESS_TOKEN);
    localStorage.removeItem(AUTH_KEYS.REFRESH_TOKEN);
    sessionStorage.removeItem(AUTH_KEYS.ACCESS_TOKEN);
    sessionStorage.removeItem(AUTH_KEYS.REFRESH_TOKEN);
  }

  static getRememberMe(): boolean {
    return localStorage.getItem(AUTH_KEYS.REMEMBER_ME) === "true";
  }
}

export { AUTH_KEYS };

import { router } from "@/router";
import { useUserStore } from "@stores";
import { ElMessage, ElNotification } from "element-plus";
import type { OAuthProvider } from "@/api/module_system/auth";

/** 登录页跳转进行中，合并并发调用，避免重复通知与重复路由 */
let redirectToLoginInFlight: Promise<void> | null = null;

/**
 * 认证失效或需重新登录时跳转登录页：清空本地会话并带上 redirect。
 * 与 HTTP 拦截器、改密后重登等场景共用；并发只执行一次。
 */
export async function redirectToLogin(message: string = "请重新登录"): Promise<void> {
  if (redirectToLoginInFlight) return redirectToLoginInFlight;

  redirectToLoginInFlight = (async () => {
    try {
      ElNotification({
        title: "提示",
        message,
        type: "warning",
        duration: 3000,
      });

      await useUserStore().resetAllState();

      const currentPath = router.currentRoute.value.fullPath;
      await router.push(`/login?redirect=${encodeURIComponent(currentPath)}`);
    } catch (error: any) {
      ElMessage.error(error?.message ?? String(error));
    } finally {
      redirectToLoginInFlight = null;
    }
  })();

  return redirectToLoginInFlight;
}

// ── OAuth 第三方登录 ──

/**
 * 跳转浏览器至后端 OAuth 入口，授权完成后回到 `redirect_uri`（通常为当前站点 /login）。
 */
export function startOAuthLogin(provider: OAuthProvider): void {
  const base = (import.meta.env.VITE_APP_BASE_API || "/api/v1").replace(/\/$/, "");
  const basePath = (import.meta.env.BASE_URL || "/").replace(/\/$/, "");
  const redirectUri = `${window.location.origin}${basePath}/login`;
  const url = `${base}/system/auth/oauth/${provider}/login?redirect_uri=${encodeURIComponent(redirectUri)}`;
  window.location.href = url;
}
