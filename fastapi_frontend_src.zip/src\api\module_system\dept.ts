import { request } from "@utils";

const API_PATH = "/system/dept";

const DeptAPI = {
  listDept(query?: DeptPageQuery) {
    return request<ApiResponse<DeptTable[]>>({
      url: `${API_PATH}/tree`,
      method: "get",
      params: query,
    });
  },

  detailDept(id: number) {
    return request<ApiResponse<DeptTable>>({
      url: `${API_PATH}/detail/${id}`,
      method: "get",
    });
  },

  createDept(body: DeptForm) {
    return request<ApiResponse>({
      url: `${API_PATH}/create`,
      method: "post",
      data: body,
    });
  },

  updateDept(id: number, body: DeptForm) {
    return request<ApiResponse>({
      url: `${API_PATH}/update/${id}`,
      method: "put",
      data: body,
    });
  },

  deleteDept(body: number[]) {
    return request<ApiResponse>({
      url: `${API_PATH}/delete`,
      method: "delete",
      data: body,
    });
  },

  batchDept(body: BatchType) {
    return request<ApiResponse>({
      url: `${API_PATH}/status/batch`,
      method: "patch",
      data: body,
    });
  },
};

export default DeptAPI;

export interface DeptPageQuery extends UserByQueryParams {
  name?: string;
  status?: number;
}

export interface DeptTable extends BaseType {
  name?: string;
  order?: number;
  code: string;
  parent_id?: number;
  parent_name?: string;
  children?: DeptTable[];
  status?: number;
  description?: string;
}

export interface DeptForm extends BaseFormType {
  name?: string;
  code: string;
  parent_id?: number;
  order?: number;
  status?: number;
  description?: string;
}
