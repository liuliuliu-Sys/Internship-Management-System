<template>
  <div>
    <FaSectionTitle :title="$t('setting.container.title')" class="mt-12.5" />
    <div class="flex">
      <div
        v-for="option in containerWidthOptions"
        :key="option.value"
        class="flex items-center justify-center flex-1 h-16 mt-5 mr-3.5 mb-3.5 cursor-pointer border-2! rounded-lg text-g-800! last:mr-0"
        :class="{
          'border-theme [&_i]:text-theme!': containerWidth === option.value,
          'border border-(--default-border)': containerWidth !== option.value,
        }"
        @click="containerHandlers.setWidth(option.value)"
      >
        <FaSvgIcon :icon="option.icon" class="mr-2 text-lg" />
        <span class="text-sm">{{ option.label }}</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useSettingsStore } from "@stores";

defineOptions({ name: "FaContainerSettings" });
import { useSettingsConfig } from "../composables/useSettingsConfig";
import { useSettingsHandlers } from "../composables/useSettingsHandlers";
import { storeToRefs } from "pinia";

const settingStore = useSettingsStore();
const { containerWidth } = storeToRefs(settingStore);
const { containerWidthOptions } = useSettingsConfig();
const { containerHandlers } = useSettingsHandlers();
</script>
