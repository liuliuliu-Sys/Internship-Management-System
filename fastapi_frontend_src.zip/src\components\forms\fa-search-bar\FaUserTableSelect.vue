<!-- 列表选择器 -->
<template>
  <FaTableSelect
    :text="text"
    :select-config="selectConfig"
    @confirm-click="handleConfirm"
    @clear-click="handleClearSelection"
  >
    <template #status="scope">
      <template v-if="scope.row[scope.prop] === 0">
        <ElTag type="success">启用</ElTag>
      </template>
      <template v-else-if="scope.row[scope.prop] === 1">
        <ElTag type="danger">停用</ElTag>
      </template>
      <template v-else>
        <ElTag type="info">未知</ElTag>
      </template>
    </template>
  </FaTableSelect>
</template>

<script setup lang="ts">
import type { ISelectConfig } from "@/components/tables/fa-table-select/index.vue";
import FaTableSelect from "@/components/tables/fa-table-select/index.vue";
import UserAPI, { UserPageQuery } from "@/api/module_system/user";

defineOptions({ name: "FaUserTableSelect" });

interface Props {
  modelValue?: number;
}

const props = withDefaults(defineProps<Props>(), {});

interface Emits {
  confirmClick: [data: IUser[]];
  "update:modelValue": [val: number | undefined];
}

const emit = defineEmits<Emits>();

const selectConfig: ISelectConfig = {
  pk: "id",
  /** 与 FaSearchBar 栅格内 ElInput 一致，占满表单项内容区 */
  width: "100%",
  placeholder: "请选择用户",
  popover: {
    width: 720, // 弹出层宽度，提升可用性（约 720px）
  },
  formItems: [
    {
      type: "select",
      label: "状态",
      prop: "status",
      initialValue: 0,
      attrs: {
        placeholder: "全部",
        clearable: true,
        style: {
          width: "140px",
        },
      },
      options: [
        { label: "启用", value: 0 },
        { label: "停用", value: 1 },
      ],
    },
  ],
  async indexAction(params: UserPageQuery) {
    // 映射查询参数到后端接口
    const query: any = { ...params };
    // 清理空字符串/空值，避免后端 422
    Object.keys(query).forEach((k) => {
      const v = query[k];
      if (v === "" || v === null || v === undefined) {
        delete query[k];
      }
    });
    // 请求用户分页列表并适配 TableSelect 需要的结构
    const res = await UserAPI.listUser(query);
    return {
      total: res.data.data.total,
      list: res.data.data.items,
    };
  },
  tableColumns: [
    { type: "selection", width: 50, align: "center" },
    { label: "编号", align: "center", prop: "id", width: 100 },
    { label: "账号", align: "center", prop: "username" },
    { label: "用户名", align: "center", prop: "name", width: 120 },
    {
      label: "状态",
      align: "center",
      prop: "status",
      templet: "custom",
      slotName: "status",
    },
  ],
};

interface IUser {
  id: number;
  username: string;
  name: string;
  mobile?: string;
  gender?: string;
  avatar?: string;
  email?: string | null;
  status?: number;
  dept_name?: string;
  role_names?: string[];
  created_time?: string;
}
const selectedUser = ref<IUser>();
function handleConfirm(data: IUser[]) {
  selectedUser.value = data[0];
  const id = selectedUser.value?.id;
  emit("update:modelValue", id);
  emit("confirmClick", data);
}
function handleClearSelection() {
  selectedUser.value = undefined;
  emit("update:modelValue", undefined);
}

// 当父组件重置 v-model（modelValue）为 undefined 时，清空本地显示
watch(
  () => props.modelValue,
  (val) => {
    if (val === undefined || val === null) {
      selectedUser.value = undefined;
    }
  }
);

const text = computed(() => {
  return selectedUser.value ? `${selectedUser.value.username} - ${selectedUser.value.name}` : "";
});
</script>
