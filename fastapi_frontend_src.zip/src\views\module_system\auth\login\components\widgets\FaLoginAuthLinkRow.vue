<!-- 登录区底部：灰色提示 + 主题链（注册 / 返回登录等） -->
<template>
  <div
    class="login-auth-link-row mt-6 flex flex-wrap items-center justify-center gap-1 text-sm leading-normal"
  >
    <span class="inline-flex items-center text-(--el-text-color-secondary)">{{ hint }}</span>
    <ElLink
      type="primary"
      underline="never"
      class="inline-flex items-center font-medium leading-[inherit]!"
      @click="$emit('link')"
    >
      {{ linkText }}
    </ElLink>
  </div>
</template>

<script setup lang="ts">
defineOptions({ name: "FaLoginAuthLinkRow" });

interface Props {
  hint: string;
  linkText: string;
}

withDefaults(defineProps<Props>(), {});

interface Emits {
  link: [];
}

defineEmits<Emits>();
</script>
