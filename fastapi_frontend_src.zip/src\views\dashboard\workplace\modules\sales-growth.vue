<template>
  <div class="fa-card h-53 p-5 pt-3.5">
    <div class="fa-card-header">
      <div class="title">
        <h4 class="text-2xl">
          <span>12%</span>
          <FaSvgIcon icon="ri:arrow-right-up-line" class="text-success text-lg ml-1" />
        </h4>
        <p>增长</p>
      </div>
    </div>

    <FaLineChart
      :showAreaColor="true"
      :showAxisLabel="false"
      :showAxisLine="false"
      :showSplitLine="false"
      :data="[50, 85, 65, 95, 75, 130, 180]"
      barWidth="16px"
      height="5rem"
    />
  </div>
</template>
